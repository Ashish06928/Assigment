﻿namespace BankManagementSystem.Services.DataServices
{
    public interface IService
    {
    }
}
