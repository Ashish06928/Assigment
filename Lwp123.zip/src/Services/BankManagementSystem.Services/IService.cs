﻿namespace BankManagementSystem.Services
{
    public interface IService
    {
    }
}
