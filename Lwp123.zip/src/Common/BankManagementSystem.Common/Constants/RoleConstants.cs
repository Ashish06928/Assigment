﻿namespace BankManagementSystem.Common.Constants
{
    public class RolesConstants
    {
        public const string Administrator = "Administrator";
        public const string User = "User";
    }
}
