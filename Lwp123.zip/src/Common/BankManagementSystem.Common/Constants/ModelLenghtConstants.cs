﻿namespace BankManagementSystem.Common.Constants
{
    public static class ModelLenghtConstants
    {
        public const int NameMaxLength = 30;
        public const int NameMinLength = 2;
    }
}
