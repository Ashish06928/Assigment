﻿namespace BankManagementSystem.Web.Pages.Withdraw
{
    using Microsoft.AspNetCore.Mvc.RazorPages;

    public class SuccessModel : PageModel
    {
    }
}